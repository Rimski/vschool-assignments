this project helped me understand how to get imformation from a form and display it elseware,
as well as some style practice without bootstrap.